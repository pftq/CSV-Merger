CSV Merger
by pftq
July 10, 2012

  This is a quick application for merging all CSVs in a folder to one file.  It features a simple user interface and a few extra options, such as choosing the header row and what rows from all files to extract.
  
  Additional features include:
  - ability to extract a particular cell from each CSV and add it as a new column.
  - settings will be remembered the next time you run the application.
  - can be run from commandline (for scripts) using "CSVMerger -run"; it will automatically use your saved settings.
  
  This was created in C# for a few tasks I needed to get done, but perhaps others out there might also find it useful.